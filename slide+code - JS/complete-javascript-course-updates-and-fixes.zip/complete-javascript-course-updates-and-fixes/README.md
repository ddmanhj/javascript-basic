# 🐛 UPDATED and FIXED Code for my Complete JavaScript Course

The _master_ branch in this repo contains the code **exactly** as shown in the course videos. However, some parts of the code contain small bugs or need updates. That's what _this_ branch is for.

**This branch will be kept up-to-date over time with latest package updates and important bugfixes 🐛**

So if you have any problem with the code in one of the course sections, check out the final code in this branch. Note that only folders with the 🐛 icon in the commit message have seen an update.

Happy coding! ✌️
